print("Ecommerce  package was initialized")
