def get_contract_details():
    pass
